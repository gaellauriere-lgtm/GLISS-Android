# GLISS — Édition Polaire 1.0.0 (base graphique V7)

Première refonte visuelle complète du jeu GLISS, construite sur le moteur de jeu HTML existant afin de conserver ses règles, son tour par tour, ses collisions, sa physique, le score jusqu'à 5, le chronomètre de 3 minutes, les effets sonores et la saisie des noms.

## Direction artistique

- Univers banquise / aurores boréales, neige et reliefs glacés.
- Patinoire lumineuse avec double contour bleu nuit et blanc givré.
- Palets-mascottes turquoise et rose, avec visages cartoon 3D stylisés (aucun humain), célébration GOAL avec mascottes et pluie de paillettes (V7).
- Ballon noir cerclé d'or, marquages de hockey et buts colorés.
- Interface mobile immersive, adaptée au format portrait.

## Projet Android

- Application ID : `fr.gliss.game`
- Version : `1.0.0-polaire` (versionCode 100, première APK de test)
- Orientation : portrait
- Minimum Android : API 23
- Jeu HTML embarqué localement dans `app/src/main/assets/index.html`
- WebView avec JavaScript, stockage local, audio et demande de permission micro.

## Compiler l'APK de test

Le workflow GitHub Actions est prêt dans `.github/workflows/android.yml`.

1. Créer un dépôt GitHub vide et y importer le contenu de ce dossier.
2. Ouvrir l'onglet **Actions** et activer les workflows si GitHub le demande.
3. Lancer **Build GLISS APK** avec **Run workflow** (ou pousser un commit sur `main`).
4. Télécharger l'artefact `GLISS-1.0.0-polaire-debug` à la fin du travail.
5. Extraire `app-debug.apk` et l'installer sur Android.

L'APK debug est destiné aux essais et au partage de test. Une version destinée à Google Play nécessitera une signature de publication et des essais complémentaires sur appareils réels.

## Vérifications effectuées dans cet environnement

- Contrôle de syntaxe JavaScript avec `node --check`.
- Contrôle de la présence des ressources et fichiers Android.

La compilation Android elle-même doit être exécutée par GitHub Actions, car le SDK Android n'est pas installé dans l'environnement de création courant.
